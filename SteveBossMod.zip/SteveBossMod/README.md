# The Steve Boss Fight (Minecraft Forge 1.7.10)

A 3-phase custom boss. Spawn with the **Steve spawn egg** (Creative > Misc) or `/summon SteveBoss`.
Test in **Survival** (`/gamemode 0`) - mobs ignore Creative players.

## One-time setup
1. Install **JDK 8**.
2. Download the **Forge 1.7.10 MDK** (10.13.4.1614) from https://files.minecraftforge.net/net/minecraftforge/forge/index_1.7.10.html
3. From the MDK zip copy these into this folder (they are the Gradle wrapper, I can't generate them):
   - `gradlew`
   - `gradlew.bat`
   - `gradle/` (the whole folder)
4. Build: `gradlew setupDecompWorkspace build` -> your jar is in `build/libs/SteveBossFight-1.0.0.jar`
5. Drop the jar into `.minecraft/mods/` with Forge 1.7.10 installed.

## Push to GitHub
    git init
    git add .
    git commit -m "Steve boss"
    git branch -M main
    git remote add origin https://github.com/YOUR_NAME/YOUR_REPO.git
    git push -u origin main
GitHub Actions (.github/workflows/build.yml) then builds the jar on every push:
Actions tab > latest run > Artifacts > SteveBossFight-jar.

## Tuning
All balance numbers are at the top of `EntitySteveBoss.java` (TUNING CONSTANTS).
Sounds are in `SteveSounds.java`. Poses are in `ModelSteveBoss.java`.
