package com.steveboss.client;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.BossStatus;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.util.ResourceLocation;

/** Renders Steve with his skin and feeds the vanilla boss health bar at the top of the screen. */
public class RenderSteveBoss extends RenderBiped {

    /** YOUR SKIN GOES HERE (64x32 PNG): assets/steveboss/textures/entity/steve_boss.png */
    private static final ResourceLocation TEXTURE =
            new ResourceLocation("steveboss", "textures/entity/steve_boss.png");

    public RenderSteveBoss() {
        super(new ModelSteveBoss(), 0.6F);
    }

    @Override
    public void doRender(Entity entity, double x, double y, double z, float yaw, float partialTicks) {
        if (entity instanceof IBossDisplayData) {
            // This one line is what draws the boss bar (same call the Wither / Ender Dragon renderers use)
            BossStatus.setBossStatus((IBossDisplayData) entity, true);
        }
        super.doRender(entity, x, y, z, yaw, partialTicks);
    }

    @Override
    protected void preRenderCallback(EntityLivingBase entity, float partialTicks) {
        super.preRenderCallback(entity, partialTicks);
        GL11.glScalef(1.1F, 1.1F, 1.1F); // slightly bigger than a normal player
    }

    @Override
    protected ResourceLocation getEntityTexture(Entity entity) {
        return TEXTURE;
    }
}
