package com.steveboss.client;

import com.steveboss.entity.EntitySteveBoss;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraft.client.Minecraft;

/**
 * Starts the boss music when a living Steve is within 80 blocks of the player,
 * stops it when he dies / you leave / you run away.
 */
public class BossMusicHandler {

    private BossMusic current = null;
    private int timer = 0;

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.thePlayer == null) {
            stop(mc);
            return;
        }

        if (++timer < 10) return; // check twice a second
        timer = 0;

        boolean bossNear = false;
        for (Object o : mc.theWorld.loadedEntityList) {
            if (o instanceof EntitySteveBoss) {
                EntitySteveBoss boss = (EntitySteveBoss) o;
                if (boss.isEntityAlive() && boss.getDistanceToEntity(mc.thePlayer) < 80.0F) {
                    bossNear = true;
                    break;
                }
            }
        }

        if (bossNear && current == null) {
            current = new BossMusic();
            mc.getSoundHandler().playSound(current);
        } else if (!bossNear) {
            stop(mc);
        }
    }

    private void stop(Minecraft mc) {
        if (current != null) {
            mc.getSoundHandler().stopSound(current);
            current = null;
        }
    }
}
