package com.steveboss.client;

import net.minecraft.client.audio.ISound;
import net.minecraft.util.ResourceLocation;

/** A looping, non-positional sound = boss music. Defined in assets/steveboss/sounds.json */
public class BossMusic implements ISound {

    private final ResourceLocation location = new ResourceLocation("steveboss", "music.steve_boss");

    @Override public ResourceLocation getPositionedSoundLocation() { return location; }
    @Override public boolean canRepeat()      { return true; }   // loop
    @Override public int getRepeatDelay()     { return 0; }
    @Override public float getVolume()        { return 1.0F; }   // still scaled by the player's Music slider
    @Override public float getPitch()         { return 1.0F; }
    @Override public float getXPosF()         { return 0.0F; }
    @Override public float getYPosF()         { return 0.0F; }
    @Override public float getZPosF()         { return 0.0F; }
    @Override public AttenuationType getAttenuationType() { return AttenuationType.NONE; } // same volume everywhere
}
