package com.steveboss.client;

import com.steveboss.entity.EntitySteveBoss;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

/**
 * ANIMATION HOOKS (standard model states - GeckoLib does not exist for 1.7.10).
 *
 * The server sets a state on the entity (EntitySteveBoss.STATE_*), it is synced through the
 * DataWatcher, and this model reads it every frame to pose the arms/body.
 * Want a different pose? Edit the matching case below. 'ticks' = how long the state has been active.
 */
public class ModelSteveBoss extends ModelBiped {

    public ModelSteveBoss() {
        super(0.0F);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch, float scale, Entity entity) {

        int state = EntitySteveBoss.STATE_IDLE;
        int ticks = 0;
        if (entity instanceof EntitySteveBoss) {
            EntitySteveBoss boss = (EntitySteveBoss) entity;
            state = boss.getState();
            ticks = boss.clientStateTicks;
        }

        this.heldItemRight = 1;
        this.aimedBow = (state == EntitySteveBoss.STATE_BOW);

        // vanilla biped walking/looking/bow-aim first, then we override on top
        super.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entity);

        switch (state) {
            case EntitySteveBoss.STATE_SHIELD:
                // arms crossed in front of the chest, like a blocking stance
                this.bipedRightArm.rotateAngleX = -1.15F;
                this.bipedRightArm.rotateAngleY = -0.65F;
                this.bipedRightArm.rotateAngleZ = 0.0F;
                this.bipedLeftArm.rotateAngleX = -1.25F;
                this.bipedLeftArm.rotateAngleY = 0.75F;
                this.bipedLeftArm.rotateAngleZ = 0.0F;
                break;

            case EntitySteveBoss.STATE_SLAM:
                if (ticks < 14) {
                    // wind-up: raise both fists over the head
                    float lift = ticks / 14.0F;
                    this.bipedRightArm.rotateAngleX = -3.0F * lift;
                    this.bipedLeftArm.rotateAngleX = -3.0F * lift;
                    this.bipedRightArm.rotateAngleZ = 0.25F * lift;
                    this.bipedLeftArm.rotateAngleZ = -0.25F * lift;
                } else {
                    // impact: fists smashed down, body leaning forward
                    this.bipedRightArm.rotateAngleX = -0.3F;
                    this.bipedLeftArm.rotateAngleX = -0.3F;
                    this.bipedBody.rotateAngleX = 0.45F;
                    this.bipedHead.rotateAngleX += 0.3F;
                }
                break;

            case EntitySteveBoss.STATE_TOTEM:
                // arms thrown skyward, trembling a little
                float shake = MathHelper.sin(ageInTicks * 1.4F) * 0.06F;
                this.bipedRightArm.rotateAngleX = -3.1F + shake;
                this.bipedLeftArm.rotateAngleX = -3.1F - shake;
                this.bipedRightArm.rotateAngleZ = 0.35F;
                this.bipedLeftArm.rotateAngleZ = -0.35F;
                break;

            default:
                break;
        }
    }
}
