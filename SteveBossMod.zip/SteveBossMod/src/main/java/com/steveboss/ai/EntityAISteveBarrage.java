package com.steveboss.ai;

import com.steveboss.entity.EntitySteveBoss;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;

/**
 * Phase 3 bow mode movement. The actual arrow firing + cooldowns live in
 * EntitySteveBoss.barrageTick(); this goal only handles WHERE Steve stands:
 *   too close  -> backpedal
 *   too far    -> close the gap
 *   otherwise  -> strafe sideways while shooting
 */
public class EntityAISteveBarrage extends EntityAIBase {

    private final EntitySteveBoss boss;
    private EntityLivingBase target;
    private int strafeTimer = 0;
    private int strafeDir = 1;

    public EntityAISteveBarrage(EntitySteveBoss boss) {
        this.boss = boss;
        this.setMutexBits(3);
    }

    @Override
    public boolean shouldExecute() {
        EntityLivingBase t = boss.getAttackTarget();
        if (t == null || !t.isEntityAlive() || !boss.isBowMode()) return false;
        this.target = t;
        return true;
    }

    @Override
    public boolean continueExecuting() {
        return shouldExecute();
    }

    @Override
    public void resetTask() {
        boss.getNavigator().clearPathEntity();
        target = null;
    }

    @Override
    public void updateTask() {
        boss.getLookHelper().setLookPositionWithEntity(target, 60.0F, 60.0F);
        if (boss.isBusy()) {
            boss.getNavigator().clearPathEntity();
            return;
        }

        double dist = boss.getDistanceToEntity(target);

        if (--strafeTimer <= 0) {
            strafeTimer = 10 + boss.getRNG().nextInt(20);
            strafeDir = boss.getRNG().nextBoolean() ? 1 : -1;
        }

        double dx = boss.posX - target.posX;
        double dz = boss.posZ - target.posZ;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.01D) len = 0.01D;
        dx /= len;
        dz /= len;

        if (dist < 9.0D) {
            // backpedal while sliding sideways
            double tx = boss.posX + dx * 5.0D - dz * strafeDir * 3.0D;
            double tz = boss.posZ + dz * 5.0D + dx * strafeDir * 3.0D;
            boss.getNavigator().clearPathEntity();
            boss.getMoveHelper().setMoveTo(tx, boss.posY, tz, 1.1D);
        } else if (dist > 22.0D) {
            boss.getNavigator().tryMoveToEntityLiving(target, 1.0D);
        } else {
            double tx = boss.posX - dz * strafeDir * 4.0D;
            double tz = boss.posZ + dx * strafeDir * 4.0D;
            boss.getNavigator().clearPathEntity();
            boss.getMoveHelper().setMoveTo(tx, boss.posY, tz, 1.0D);
        }
    }
}
