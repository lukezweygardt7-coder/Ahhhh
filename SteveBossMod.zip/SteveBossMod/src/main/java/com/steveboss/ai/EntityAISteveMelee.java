package com.steveboss.ai;

import com.steveboss.entity.EntitySteveBoss;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;

/**
 * Steve's "human" melee behaviour:
 *  - chases with a path, repathing at random intervals
 *  - when close, randomly circle-strafes left/right instead of running in a straight line (erratic)
 *  - jumps in for critical hits
 *  - swings every ~0.5s (PvP speed)
 *  - stands still while the shield is up or during slam/totem animations
 *
 * Runs whenever the boss is NOT in bow mode.
 */
public class EntityAISteveMelee extends EntityAIBase {

    private static final double REACH = 3.3D;

    private final EntitySteveBoss boss;
    private EntityLivingBase target;

    private int repathTimer = 0;
    private int strafeTimer = 0;
    private int strafeDir = 1;
    private boolean strafing = false;

    public EntityAISteveMelee(EntitySteveBoss boss) {
        this.boss = boss;
        this.setMutexBits(3); // controls movement + looking
    }

    @Override
    public boolean shouldExecute() {
        EntityLivingBase t = boss.getAttackTarget();
        if (t == null || !t.isEntityAlive() || boss.isBowMode()) return false;
        this.target = t;
        return true;
    }

    @Override
    public boolean continueExecuting() {
        return shouldExecute();
    }

    @Override
    public void startExecuting() {
        repathTimer = 0;
        strafeTimer = 0;
    }

    @Override
    public void resetTask() {
        boss.getNavigator().clearPathEntity();
        target = null;
    }

    @Override
    public void updateTask() {
        boss.getLookHelper().setLookPositionWithEntity(target, 40.0F, 40.0F);

        // frozen states
        if (boss.isBusy() || boss.isShielding()) {
            boss.getNavigator().clearPathEntity();
            return;
        }

        double dist = boss.getDistanceToEntity(target);

        // --- erratic strafing: re-roll direction / whether to strafe every 0.75-2s ---
        if (--strafeTimer <= 0) {
            strafeTimer = 15 + boss.getRNG().nextInt(25);
            strafeDir = boss.getRNG().nextBoolean() ? 1 : -1;
            strafing = boss.getRNG().nextInt(3) != 0; // 2/3 of the time when close
        }

        if (dist < 6.0D && dist > 1.5D && strafing) {
            // point on a circle around the target, rotated a bit in strafeDir
            double a = Math.atan2(boss.posZ - target.posZ, boss.posX - target.posX) + strafeDir * 0.55D;
            double r = Math.max(2.4D, dist - 0.3D); // keep spiralling inward a little
            double tx = target.posX + Math.cos(a) * r;
            double tz = target.posZ + Math.sin(a) * r;
            boss.getNavigator().clearPathEntity();
            boss.getMoveHelper().setMoveTo(tx, target.posY, tz, 1.15D);
        } else if (--repathTimer <= 0) {
            repathTimer = 4 + boss.getRNG().nextInt(7);
            boss.getNavigator().tryMoveToEntityLiving(target, 1.0D);
        }

        // --- critical leap: jump in from mid range so the landing hit crits ---
        if (dist > 2.6D && dist < 5.5D && boss.canCritLeap() && boss.getRNG().nextInt(6) == 0) {
            boss.critLeap(target);
        }

        // --- attack ---
        boolean inReach = dist <= REACH && Math.abs(boss.posY - target.posY) < 2.2D;
        if (inReach && boss.attackDelay <= 0 && boss.getEntitySenses().canSee(target)) {
            boss.swingItem();
            boss.attackEntityAsMob(target);
            boss.attackDelay = 9 + boss.getRNG().nextInt(4); // ~0.5s
        }
    }
}
