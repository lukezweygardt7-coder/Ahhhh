package com.steveboss.event;

import com.steveboss.entity.EntitySteveArrow;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

public class SteveEvents {

    /**
     * Turns a normal arrow hit from Steve's arrows into an armour-piercing one.
     * We cancel the vanilla hit and re-apply the same damage with a source that bypasses armour.
     * (isUnblockable() == true on our new source, so this handler ignores the second pass.)
     */
    @SubscribeEvent
    public void onLivingAttack(LivingAttackEvent event) {
        DamageSource src = event.source;
        if (src.isUnblockable()) {
            return;
        }
        if (src.getSourceOfDamage() instanceof EntitySteveArrow) {
            EntitySteveArrow arrow = (EntitySteveArrow) src.getSourceOfDamage();
            event.setCanceled(true);
            event.entityLiving.attackEntityFrom(new SteveArrowDamage(arrow, arrow.shootingEntity), event.ammount);
            arrow.setDead();
        }
    }
}
