package com.steveboss.event;

import net.minecraft.entity.Entity;
import net.minecraft.util.EntityDamageSourceIndirect;

/** Projectile damage that ignores armour. (Subclass so we can call the protected setters.) */
public class SteveArrowDamage extends EntityDamageSourceIndirect {
    public SteveArrowDamage(Entity arrow, Entity shooter) {
        super("arrow", arrow, shooter);
        this.setDamageBypassesArmor();
        this.setProjectile();
    }
}
