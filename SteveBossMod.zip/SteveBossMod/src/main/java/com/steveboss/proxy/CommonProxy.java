package com.steveboss.proxy;

public class CommonProxy {
    /** Server side: nothing to do. ClientProxy overrides this. */
    public void registerClientStuff() {
    }
}
