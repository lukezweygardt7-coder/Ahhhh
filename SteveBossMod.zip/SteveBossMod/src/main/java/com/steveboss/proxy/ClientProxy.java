package com.steveboss.proxy;

import com.steveboss.client.BossMusicHandler;
import com.steveboss.client.RenderSteveBoss;
import com.steveboss.entity.EntitySteveBoss;

import cpw.mods.fml.client.registry.RenderingRegistry;
import cpw.mods.fml.common.FMLCommonHandler;

public class ClientProxy extends CommonProxy {
    @Override
    public void registerClientStuff() {
        // Model + texture + boss health bar
        RenderingRegistry.registerEntityRenderingHandler(EntitySteveBoss.class, new RenderSteveBoss());
        // Boss music (client tick)
        FMLCommonHandler.instance().bus().register(new BossMusicHandler());
    }
}
