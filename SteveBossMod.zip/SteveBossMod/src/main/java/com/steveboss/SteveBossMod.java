package com.steveboss;

import com.steveboss.entity.EntitySteveBoss;
import com.steveboss.event.SteveEvents;
import com.steveboss.proxy.CommonProxy;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.EntityRegistry;
import net.minecraftforge.common.MinecraftForge;

/**
 * Minimal mod entry point. All the interesting stuff lives in EntitySteveBoss.
 */
@Mod(modid = SteveBossMod.MODID, name = "The Steve Boss Fight", version = "1.0.0")
public class SteveBossMod {

    public static final String MODID = "steveboss";

    @Mod.Instance(MODID)
    public static SteveBossMod instance;

    @SidedProxy(clientSide = "com.steveboss.proxy.ClientProxy",
                serverSide = "com.steveboss.proxy.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        // Global id + spawn egg (creative tab "Misc"). /summon SteveBoss also works.
        int id = EntityRegistry.findGlobalUniqueEntityId();
        EntityRegistry.registerGlobalEntityID(EntitySteveBoss.class, "SteveBoss", id, 0x2B7A8C, 0x6E3FA3);

        // Tracking: range 128 blocks, update every tick, send velocity.
        EntityRegistry.registerModEntity(EntitySteveBoss.class, "SteveBoss", 0, this, 128, 1, true);

        // Armour-piercing arrow handler
        MinecraftForge.EVENT_BUS.register(new SteveEvents());

        proxy.registerClientStuff();
    }
}
