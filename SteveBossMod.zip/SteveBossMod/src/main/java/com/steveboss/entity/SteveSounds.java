package com.steveboss.entity;

/**
 * SOUND DESIGN HOOKS.
 * Every boss sound goes through one of these strings, so you can swap any of them later.
 *
 * Right now they point at vanilla 1.7.10 sounds as placeholders.
 * To use your own sound:
 *   1. drop  my_sound.ogg  into  src/main/resources/assets/steveboss/sounds/
 *   2. add to sounds.json:   "sfx.teleport": { "category": "hostile", "sounds": ["my_sound"] }
 *   3. change the string below to  "steveboss:sfx.teleport"
 */
public final class SteveSounds {
    private SteveSounds() {}

    public static final String TELEPORT     = "mob.endermen.portal";
    public static final String TNT_CAST     = "random.fuse";
    public static final String CRIT_LEAP    = "mob.irongolem.throw";
    public static final String CRIT_HIT     = "random.successful_hit";
    public static final String SLAM_WINDUP  = "mob.enderdragon.growl";
    public static final String SLAM_IMPACT  = "random.explode";
    public static final String SUMMON       = "mob.zombie.say";
    public static final String SHIELD_UP    = "random.anvil_land";
    public static final String PARRY        = "random.break";
    public static final String COUNTER      = "mob.irongolem.death";
    public static final String PHASE_CHANGE = "mob.enderdragon.growl";
    public static final String TOTEM_POP    = "mob.wither.spawn";
    public static final String BOW          = "random.bow";
    public static final String HURT         = "game.player.hurt";
    public static final String DEATH        = "game.player.die";
}
