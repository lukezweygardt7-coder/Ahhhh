package com.steveboss.entity;

import java.util.List;

import com.steveboss.ai.EntityAISteveBarrage;
import com.steveboss.ai.EntityAISteveMelee;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/**
 * STEVE - the ultimate PvP player.
 *
 * Structure of this class:
 *   1. TUNING CONSTANTS      - change numbers here to rebalance the fight
 *   2. STATE / COOLDOWNS     - everything the boss "remembers"
 *   3. CONSTRUCTOR / AI      - attributes + AI task registration
 *   4. MAIN TICK             - phase detection + ability brain
 *   5. ABILITIES             - teleport, TNT, slam/minions, shield/parry, bow barrage, totem
 *   6. DAMAGE HOOKS          - parry, projectile reaction, totem "death" interception
 *   7. HELPERS               - particles, sounds, chat
 */
public class EntitySteveBoss extends EntityMob implements IBossDisplayData {

    // =====================================================================
    // 1. TUNING CONSTANTS
    // =====================================================================
    public static final double MAX_HEALTH      = 500.0D;
    public static final double BASE_SPEED      = 0.30D;   // a bit faster than player sprint
    public static final double SPRINT_SPEED    = 0.42D;   // phase 3 "giga sprint"
    public static final int    NATURAL_ARMOR   = 10;      // 0-20. 10 = takes 60% damage (diamond sword 7 -> ~4.2)
    public static final float  BASE_DAMAGE     = 18.0F;   // vs full diamond ~3.6 per hit
    public static final float  CRIT_MULT       = 2.2F;    // jump-crit multiplier (~8 per hit vs full diamond)
    public static final float  TOTEM_HEAL      = 100.0F;
    public static final float  ARROW_DAMAGE    = 1.3F;    // arrow dmg = ceil(speed * this) -> ~3-4 + crit, ignores armour
    public static final int    ARROWS_PER_BURST = 5;
    public static final int    MAX_MINIONS     = 8;

    // Animation / render states (synced to client through the DataWatcher)
    public static final int STATE_IDLE   = 0;
    public static final int STATE_SHIELD = 1;
    public static final int STATE_SLAM   = 2;
    public static final int STATE_BOW    = 3;
    public static final int STATE_TOTEM  = 4;

    private static final int DW_PHASE = 20;
    private static final int DW_STATE = 21;

    /** Ability list with base cooldowns in ticks (20 ticks = 1 second). */
    private enum Ability {
        TELEPORT(160), TNT(110), SUMMON(560), SHIELD(280), CRIT_LEAP(70);
        final int cooldown;
        Ability(int cooldown) { this.cooldown = cooldown; }
    }

    // =====================================================================
    // 2. STATE
    // =====================================================================
    private final int[] cooldowns = new int[Ability.values().length];

    private int phase = 1;
    private boolean totemUsed = false;

    private int outOfRangeTicks = 0;          // for "target out of melee range > 3s" teleport
    private boolean projectileTeleportPending = false;

    private int slamTicks = 0;                // >0 while the ground-slam animation plays
    private int shieldTicks = 0;              // >0 while shield is raised
    private int totemTicks = 0;               // >0 while totem animation plays (invulnerable)

    private boolean bowMode = false;          // phase 3: false = sword sprint, true = bow barrage
    private int modeTimer = 0;
    private int burstLeft = 0;
    private int arrowDelay = 0;

    /** Read by the melee goal: ticks until Steve may swing again. */
    public int attackDelay = 0;

    /** CLIENT ONLY: how many ticks the current animation state has been running (for model poses). */
    public int clientStateTicks = 0;
    private int lastClientState = 0;

    // =====================================================================
    // 3. CONSTRUCTOR / AI
    // =====================================================================
    public EntitySteveBoss(World world) {
        super(world);
        this.setSize(0.66F, 1.98F);
        this.experienceValue = 500;
        this.isImmuneToFire = false;

        // --- AI tasks: lower number = higher priority ---
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(1, new EntityAISteveBarrage(this)); // phase 3 bow mode (only runs when bowMode)
        this.tasks.addTask(2, new EntityAISteveMelee(this));   // everything else
        this.tasks.addTask(8, new EntityAIWatchClosest(this, EntityPlayer.class, 24.0F));
        this.tasks.addTask(9, new EntityAILookIdle(this));

        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, false));

        // Visual gear (we do NOT put armour on him so the skin stays visible; armour is simulated below)
        this.setCurrentItemOrArmor(0, new ItemStack(Items.diamond_sword));

        // Opening cooldowns so he doesn't dump everything on tick 1
        cooldowns[Ability.TNT.ordinal()] = 80;
        cooldowns[Ability.SHIELD.ordinal()] = 160;
        cooldowns[Ability.SUMMON.ordinal()] = 200;
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(DW_PHASE, Integer.valueOf(1));
        this.dataWatcher.addObject(DW_STATE, Integer.valueOf(STATE_IDLE));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes(); // EntityMob registers attackDamage for us
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(MAX_HEALTH);
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(BASE_SPEED);
        this.getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(1.0D);
        this.getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(64.0D);
        this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(BASE_DAMAGE);
    }

    /** REQUIRED in 1.7.10 or the AI tasks never run. */
    @Override
    protected boolean isAIEnabled() {
        return true;
    }

    /** 1.7.10 mobs have no armour attribute, so we fake "high natural armour" here. */
    @Override
    public int getTotalArmorValue() {
        return NATURAL_ARMOR;
    }

    @Override
    protected boolean canDespawn() {
        return false;
    }

    @Override
    protected void fall(float distance) {
        // no fall damage for the boss (so crit leaps are free)
    }

    // =====================================================================
    // 4. MAIN TICK
    // =====================================================================
    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();

        if (this.worldObj.isRemote) {
            clientTick();
            return;
        }

        tickCooldowns();
        if (attackDelay > 0) attackDelay--;

        updatePhase();
        tickStates();

        EntityLivingBase target = this.getAttackTarget();
        if (target != null && target.isEntityAlive()) {
            abilityBrain(target);
        } else {
            outOfRangeTicks = 0;
        }

        syncState();
    }

    /** Phase 1: >60%, Phase 2: 60%-20%, Phase 3: <=20% (and permanently after the totem pop). */
    private void updatePhase() {
        float ratio = this.getHealth() / this.getMaxHealth();
        int newPhase;
        if (totemUsed || ratio <= 0.20F) newPhase = 3;
        else if (ratio <= 0.60F)         newPhase = 2;
        else                             newPhase = 1;

        if (newPhase > phase) {
            phase = newPhase;
            onPhaseChange(newPhase);
        }
    }

    private void onPhaseChange(int newPhase) {
        this.dataWatcher.updateObject(DW_PHASE, Integer.valueOf(newPhase));
        sound(SteveSounds.PHASE_CHANGE, 3.0F, 0.8F);
        fx("largeexplode", posX, posY + 1.0D, posZ, 3, 1.2D, 0.0D);
        fx("witchMagic", posX, posY + 1.0D, posZ, 60, 1.0D, 0.1D);
        shockwave(6.0D, 0.0F, 1.2D); // knockback only, makes the transition readable

        if (newPhase == 2) {
            say("You think a few hits makes you a PvPer? Boys, get him!");
            cooldowns[Ability.SUMMON.ordinal()] = 0; // summon immediately
        } else if (newPhase == 3) {
            say("ENOUGH. No more games.");
            bowMode = false;
            modeTimer = 100;
        }
    }

    /** Counts down the timed states. */
    private void tickStates() {
        // Ground slam: impact happens at tick 14 of 30
        if (slamTicks > 0) {
            slamTicks--;
            this.getNavigator().clearPathEntity();
            this.motionX = 0; this.motionZ = 0;
            if (slamTicks == 16) {
                slamImpact();
            }
        }

        // Totem animation (frozen + invulnerable)
        if (totemTicks > 0) {
            totemTicks--;
            this.getNavigator().clearPathEntity();
            this.motionX = 0; this.motionZ = 0;
            if (totemTicks % 4 == 0) {
                fx("happyVillager", posX, posY + 1.0D, posZ, 12, 0.6D, 0.0D);
                fx("fireworksSpark", posX, posY + 1.0D, posZ, 8, 0.4D, 0.15D);
            }
        }

        if (shieldTicks > 0) {
            shieldTicks--;
            if (shieldTicks == 0) cooldowns[Ability.SHIELD.ordinal()] = (int) (Ability.SHIELD.cooldown * (phase == 3 ? 0.65F : 1.0F));
        }

        // Phase 3: alternate sword-sprint and bow barrage
        if (phase == 3 && !isBusy()) {
            if (--modeTimer <= 0) {
                setBowMode(!bowMode);
            }
        }
    }

    /** Decides which ability to use this tick. Order = priority. */
    private void abilityBrain(EntityLivingBase target) {
        double dist = this.getDistanceToEntity(target);
        outOfRangeTicks = (dist > 4.0D) ? outOfRangeTicks + 1 : 0;

        if (isBusy()) return;

        // --- Teleport: out of reach > 3s OR got shot ---
        if ((outOfRangeTicks > 60 || projectileTeleportPending) && ready(Ability.TELEPORT)) {
            if (teleportBehind(target)) {
                use(Ability.TELEPORT);
                outOfRangeTicks = 0;
            }
            projectileTeleportPending = false;
        } else if (projectileTeleportPending && !ready(Ability.TELEPORT)) {
            projectileTeleportPending = false; // on cooldown: forget it
        }

        // --- Phase 2+: summon wave & shield ---
        if (phase >= 2) {
            if (ready(Ability.SUMMON) && countMinions() < MAX_MINIONS) {
                startSlam();
                return;
            }
            if (ready(Ability.SHIELD) && shieldTicks == 0 && dist < 6.0D && this.rand.nextInt(30) == 0 && !bowMode) {
                raiseShield();
            }
        }

        // --- TNT every few seconds (all phases, but not while in the bow barrage) ---
        if (ready(Ability.TNT) && dist < 28.0D && !bowMode) {
            castTnt(target);
        }

        // --- Phase 3 barrage ---
        if (phase == 3 && bowMode) {
            barrageTick(target);
        }
    }

    // =====================================================================
    // 5. ABILITIES
    // =====================================================================

    // ---------- 5a. TELEPORT BEHIND ----------
    /**
     * Instantly teleports Steve ~2 blocks behind the target (relative to where the target is facing),
     * trying a few alternate angles if the first spot is blocked. Leaves purple particles at both ends.
     *
     * @return true if a safe spot was found and the teleport happened
     */
    public boolean teleportBehind(EntityLivingBase target) {
        double yawRad = Math.toRadians(target.rotationYaw);
        // MC facing vector = (-sin(yaw), cos(yaw)); "behind" is the opposite.
        double baseX = Math.sin(yawRad);
        double baseZ = -Math.cos(yawRad);

        double fromX = this.posX, fromY = this.posY, fromZ = this.posZ;

        for (int attempt = 0; attempt < 8; attempt++) {
            // attempt 0 = straight behind, then +/-30deg, +/-60deg, ...
            double offset = ((attempt + 1) / 2) * 0.52D * ((attempt % 2 == 0) ? 1 : -1);
            double c = Math.cos(offset), s = Math.sin(offset);
            double dx = baseX * c - baseZ * s;
            double dz = baseX * s + baseZ * c;

            double nx = target.posX + dx * 2.0D;
            double nz = target.posZ + dz * 2.0D;

            for (int dy = 0; dy <= 1; dy++) {
                double ny = target.posY + dy;
                if (isSafeSpot(nx, ny, nz)) {
                    // departure effects
                    fx("portal", fromX, fromY + 1.0D, fromZ, 50, 0.5D, 0.6D);
                    fx("witchMagic", fromX, fromY + 1.0D, fromZ, 30, 0.4D, 0.1D);
                    sound(SteveSounds.TELEPORT, 1.0F, 1.0F);

                    float yaw = (float) (Math.atan2(target.posZ - nz, target.posX - nx) * 180.0D / Math.PI) - 90.0F;
                    this.setLocationAndAngles(nx, ny, nz, yaw, 0.0F);
                    this.rotationYawHead = yaw;
                    this.renderYawOffset = yaw;
                    this.getNavigator().clearPathEntity();
                    this.fallDistance = 0.0F;

                    // arrival effects
                    fx("portal", nx, ny + 1.0D, nz, 60, 0.5D, 0.6D);
                    fx("witchMagic", nx, ny + 1.0D, nz, 40, 0.5D, 0.1D);
                    sound(SteveSounds.TELEPORT, 1.0F, 1.2F);

                    this.attackDelay = 8; // tiny telegraph, then the backstab lands
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isSafeSpot(double x, double y, double z) {
        AxisAlignedBB box = this.boundingBox.getOffsetBoundingBox(x - this.posX, y - this.posY, z - this.posZ);
        if (!this.worldObj.getCollidingBoundingBoxes(this, box).isEmpty()) return false;
        if (this.worldObj.isAnyLiquid(box)) return false;
        // something solid within ~1.5 blocks below, so we don't teleport into the air
        AxisAlignedBB below = box.getOffsetBoundingBox(0.0D, -1.5D, 0.0D);
        return !this.worldObj.getCollidingBoundingBoxes(this, below).isEmpty();
    }

    // ---------- 5b. TNT ----------
    /**
     * Two patterns, chosen at random:
     *  A) "Under your feet": primes TNT on the target (and a second one a bit ahead in phase 2+).
     *  B) "Ring": a circle of TNT around Steve himself, punishing anyone hugging him.
     * Blocks are never destroyed (see EntitySteveTNT).
     */
    private void castTnt(EntityLivingBase target) {
        use(Ability.TNT);
        sound(SteveSounds.TNT_CAST, 1.5F, 1.0F);
        this.swingItem();

        boolean ring = this.rand.nextInt(3) == 0 && this.getDistanceToEntity(target) < 7.0D;

        if (!ring) {
            spawnTnt(target.posX, target.posY, target.posZ, 32, 0.0D, 0.0D);
            if (phase >= 2) {
                // lead the target: place one where they are heading
                spawnTnt(target.posX + target.motionX * 10.0D, target.posY, target.posZ + target.motionZ * 10.0D, 38, 0.0D, 0.0D);
            }
            if (phase == 3) {
                spawnTnt(target.posX + (rand.nextDouble() - 0.5D) * 4.0D, target.posY, target.posZ + (rand.nextDouble() - 0.5D) * 4.0D, 44, 0.0D, 0.0D);
            }
        } else {
            int count = 6 + phase;
            double radius = 3.0D;
            for (int i = 0; i < count; i++) {
                double angle = (Math.PI * 2.0D) * i / count;
                double tx = this.posX + Math.cos(angle) * radius;
                double tz = this.posZ + Math.sin(angle) * radius;
                // small upward hop so the ring "pops" out of the ground
                spawnTnt(tx, this.posY + 0.2D, tz, 30, 0.0D, 0.25D);
            }
        }
    }

    private void spawnTnt(double x, double y, double z, int fuse, double mx, double my) {
        EntitySteveTNT tnt = new EntitySteveTNT(this.worldObj, x, y, z, this);
        tnt.fuse = fuse;
        tnt.motionX = mx;
        tnt.motionY = my;
        tnt.motionZ = mx;
        this.worldObj.spawnEntityInWorld(tnt);
    }

    // ---------- 5c. SLAM + ZOMBIE HORDE ----------
    private void startSlam() {
        use(Ability.SUMMON);
        slamTicks = 30;          // animation length; impact at slamTicks == 16
        this.getNavigator().clearPathEntity();
        sound(SteveSounds.SLAM_WINDUP, 2.0F, 1.0F);
    }

    /** The moment the fists hit the ground: shockwave + minion wave. */
    private void slamImpact() {
        sound(SteveSounds.SLAM_IMPACT, 2.0F, 0.7F);
        sound(SteveSounds.SUMMON, 2.0F, 0.6F);

        // Expanding particle ring (3 rings at increasing radius)
        for (int ring = 1; ring <= 3; ring++) {
            double r = ring * 2.5D;
            for (int i = 0; i < 24; i++) {
                double a = (Math.PI * 2.0D) * i / 24.0D;
                fx("explode", posX + Math.cos(a) * r, posY + 0.2D, posZ + Math.sin(a) * r, 1, 0.1D, 0.02D);
            }
        }
        fx("largeexplode", posX, posY + 0.5D, posZ, 2, 0.8D, 0.0D);

        // Shockwave: 8 block radius, 6 damage, strong knockback
        shockwave(8.0D, 6.0F, 1.7D);

        // Minions
        summonMinions(this.getAttackTarget());
    }

    /**
     * Spawns 3-4 iron-geared zombies in a ring around Steve.
     * Minions are tagged "SteveMinion" in their entity NBT so we can count and clean them up.
     */
    private void summonMinions(EntityLivingBase target) {
        int count = 3 + this.rand.nextInt(2); // 3 or 4
        for (int i = 0; i < count; i++) {
            double angle = (Math.PI * 2.0D) * (i + this.rand.nextDouble() * 0.5D) / count;
            double dist = 3.0D + this.rand.nextDouble() * 1.5D;
            double x = this.posX + Math.cos(angle) * dist;
            double z = this.posZ + Math.sin(angle) * dist;

            EntityZombie zombie = new EntityZombie(this.worldObj);
            zombie.setLocationAndAngles(x, this.posY, z, this.rand.nextFloat() * 360.0F, 0.0F);
            if (!this.worldObj.getCollidingBoundingBoxes(zombie, zombie.boundingBox).isEmpty()) {
                zombie.setLocationAndAngles(this.posX, this.posY + 1.0D, this.posZ, 0.0F, 0.0F); // fallback: on top of Steve
            }

            zombie.setChild(false);
            // slot 0 = hand, 1 = boots, 2 = leggings, 3 = chestplate, 4 = helmet
            zombie.setCurrentItemOrArmor(0, new ItemStack(Items.iron_sword));
            zombie.setCurrentItemOrArmor(1, new ItemStack(Items.iron_boots));
            zombie.setCurrentItemOrArmor(2, new ItemStack(Items.iron_leggings));
            zombie.setCurrentItemOrArmor(3, new ItemStack(Items.iron_chestplate));
            zombie.setCurrentItemOrArmor(4, new ItemStack(Items.iron_helmet)); // helmet = no burning in daylight

            zombie.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(40.0D);
            zombie.setHealth(40.0F);
            zombie.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.28D);
            zombie.getEntityData().setBoolean("SteveMinion", true);
            if (target != null) zombie.setAttackTarget(target);

            this.worldObj.spawnEntityInWorld(zombie);
            fx("witchMagic", x, this.posY + 1.0D, z, 20, 0.4D, 0.05D);
        }
    }

    private List<EntityZombie> getMinions() {
        List<EntityZombie> result = new java.util.ArrayList<EntityZombie>();
        List all = this.worldObj.getEntitiesWithinAABB(EntityZombie.class, this.boundingBox.expand(48.0D, 24.0D, 48.0D));
        for (Object o : all) {
            EntityZombie z = (EntityZombie) o;
            if (z.getEntityData().getBoolean("SteveMinion") && z.isEntityAlive()) result.add(z);
        }
        return result;
    }

    private int countMinions() {
        return getMinions().size();
    }

    // ---------- 5d. SHIELD + PARRY ----------
    private void raiseShield() {
        shieldTicks = 40; // 2 seconds
        this.getNavigator().clearPathEntity();
        sound(SteveSounds.SHIELD_UP, 1.5F, 1.2F);
        fx("crit", posX, posY + 1.2D, posZ, 15, 0.5D, 0.2D);
    }

    /** Called from attackEntityFrom when a melee hit lands during the shield window. */
    private void parry(EntityLivingBase attacker) {
        sound(SteveSounds.PARRY, 1.5F, 1.0F);
        sound(SteveSounds.COUNTER, 1.5F, 1.3F);
        shieldTicks = 0;
        cooldowns[Ability.SHIELD.ordinal()] = (int) (Ability.SHIELD.cooldown * (phase == 3 ? 0.65F : 1.0F));
        this.swingItem();
        this.attackDelay = 10;

        // Sweeping counter: everything hostile within 4.5 blocks in front
        AxisAlignedBB sweep = this.boundingBox.expand(4.5D, 1.0D, 4.5D);
        List victims = this.worldObj.getEntitiesWithinAABB(EntityPlayer.class, sweep);
        for (Object o : victims) {
            EntityPlayer p = (EntityPlayer) o;
            if (p.capabilities.disableDamage) continue;
            p.hurtResistantTime = 0; // make sure the counter always lands
            p.attackEntityFrom(DamageSource.causeMobDamage(this), 9.0F);
            pushAway(p, 1.1D, 0.45D);
            p.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 100, 1)); // Slowness II, 5s
            p.addPotionEffect(new PotionEffect(Potion.weakness.id, 200, 1));      // Weakness II, 10s
        }
        // sweep arc particles
        for (int i = -4; i <= 4; i++) {
            double a = Math.toRadians(this.rotationYaw + i * 20.0D);
            fx("largeexplode", posX - Math.sin(a) * 2.5D, posY + 1.0D, posZ + Math.cos(a) * 2.5D, 1, 0.0D, 0.0D);
        }
    }

    // ---------- 5e. PHASE 3: BOW BARRAGE ----------
    private void setBowMode(boolean bow) {
        bowMode = bow;
        burstLeft = 0;
        arrowDelay = 10;
        if (bow) {
            modeTimer = 60 + this.rand.nextInt(30);
            this.setCurrentItemOrArmor(0, new ItemStack(Items.bow));
            this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(BASE_SPEED);
        } else {
            modeTimer = 90 + this.rand.nextInt(40);
            this.setCurrentItemOrArmor(0, new ItemStack(Items.diamond_sword));
            this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(SPRINT_SPEED); // GIGA SPRINT
            fx("flame", posX, posY + 0.2D, posZ, 20, 0.4D, 0.05D);
        }
    }

    private void barrageTick(EntityLivingBase target) {
        if (arrowDelay > 0) { arrowDelay--; return; }
        if (!this.getEntitySenses().canSee(target)) return;

        if (burstLeft <= 0) burstLeft = ARROWS_PER_BURST;

        EntitySteveArrow arrow = new EntitySteveArrow(this.worldObj, this, target, 2.2F, 5.0F);
        arrow.setDamage(ARROW_DAMAGE);
        arrow.setIsCritical(true); // gives the particle trail
        this.worldObj.spawnEntityInWorld(arrow);
        sound(SteveSounds.BOW, 1.0F, 1.0F / (this.rand.nextFloat() * 0.4F + 0.8F));
        this.swingItem();

        burstLeft--;
        arrowDelay = (burstLeft > 0) ? 3 : 22; // rapid fire inside a burst, pause between bursts
    }

    public boolean isBowMode() {
        return bowMode;
    }

    // ---------- 5f. TOTEM OF UNDYING ----------
    /**
     * Called instead of dying the first time health reaches 0.
     * Restores 100 HP, gives Resistance/Strength, wipes debuffs, knocks everyone back.
     */
    private void popTotem() {
        totemUsed = true;
        totemTicks = 40;
        slamTicks = 0;
        shieldTicks = 0;
        burstLeft = 0;

        this.setHealth(TOTEM_HEAL);
        this.clearActivePotions();
        this.addPotionEffect(new PotionEffect(Potion.resistance.id, 20 * 20, 2));   // Resistance III, 20s
        this.addPotionEffect(new PotionEffect(Potion.damageBoost.id, 20 * 60, 1));  // Strength II, 60s
        this.addPotionEffect(new PotionEffect(Potion.regeneration.id, 20 * 5, 1));
        setBowMode(false);
        phase = 3;
        this.dataWatcher.updateObject(DW_PHASE, Integer.valueOf(3));

        sound(SteveSounds.TOTEM_POP, 3.0F, 1.2F);
        fx("fireworksSpark", posX, posY + 1.0D, posZ, 120, 0.8D, 0.35D);
        fx("happyVillager", posX, posY + 1.0D, posZ, 60, 0.8D, 0.0D);
        fx("largeexplode", posX, posY + 1.0D, posZ, 4, 1.0D, 0.0D);

        // massive knockback wave (14 blocks, light damage)
        shockwave(14.0D, 8.0F, 2.4D);
        say("A TOTEM?! You thought it'd be that easy?");
    }

    // =====================================================================
    // 6. DAMAGE HOOKS
    // =====================================================================
    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        if (this.worldObj.isRemote) {
            return super.attackEntityFrom(source, amount);
        }

        // Immune to his own TNT / minion explosions and to the totem animation
        if (source.isExplosion()) return false;
        if (totemTicks > 0 && source != DamageSource.outOfWorld) return false;

        // Shield window: fully negate (still lets /kill and void through)
        if (shieldTicks > 0 && !source.isUnblockable() && source != DamageSource.outOfWorld) {
            Entity attacker = source.getEntity();
            if (!source.isProjectile() && attacker instanceof EntityLivingBase) {
                parry((EntityLivingBase) attacker);   // melee -> counter attack
            } else {
                sound(SteveSounds.PARRY, 1.0F, 1.5F); // arrows just bounce
                fx("crit", posX, posY + 1.2D, posZ, 6, 0.3D, 0.1D);
            }
            return false;
        }

        // Projectile reaction: remember to teleport behind the shooter
        if (source.isProjectile() && source.getEntity() instanceof EntityLivingBase) {
            this.projectileTeleportPending = true;
            if (this.getAttackTarget() == null) this.setAttackTarget((EntityLivingBase) source.getEntity());
        }

        return super.attackEntityFrom(source, amount);
    }

    /**
     * attackEntityFrom() ends by calling onDeath() when health <= 0.
     * First time: we eat the death and pop the totem instead.
     */
    @Override
    public void onDeath(DamageSource source) {
        if (!this.worldObj.isRemote && !totemUsed && source != DamageSource.outOfWorld) {
            popTotem();
            return;
        }
        if (!this.worldObj.isRemote) {
            for (EntityZombie z : getMinions()) {
                fx("witchMagic", z.posX, z.posY + 1.0D, z.posZ, 15, 0.3D, 0.05D);
                z.setDead();
            }
            say("...GG.");
        }
        super.onDeath(source);
    }

    /** Crit-aware melee hit. A "crit" = falling + airborne, like the vanilla player crit rule. */
    @Override
    public boolean attackEntityAsMob(Entity victim) {
        boolean crit = this.fallDistance > 0.0F && !this.onGround && !this.isOnLadder() && !this.isInWater();

        float damage = (float) this.getEntityAttribute(SharedMonsterAttributes.attackDamage).getAttributeValue();
        if (crit) damage *= CRIT_MULT;

        boolean hit = victim.attackEntityFrom(DamageSource.causeMobDamage(this), damage);
        if (hit) {
            float yaw = this.rotationYaw * (float) Math.PI / 180.0F;
            double kb = crit ? 0.9D : 0.5D;
            victim.addVelocity(-MathHelper.sin(yaw) * kb, crit ? 0.35D : 0.1D, MathHelper.cos(yaw) * kb);
            if (victim instanceof EntityPlayer) victim.velocityChanged = true;

            if (crit) {
                sound(SteveSounds.CRIT_HIT, 1.2F, 1.0F);
                fx("crit", victim.posX, victim.posY + victim.height * 0.5D, victim.posZ, 25, 0.4D, 0.4D);
                fx("magicCrit", victim.posX, victim.posY + victim.height * 0.5D, victim.posZ, 15, 0.4D, 0.4D);
            }
        }
        return hit;
    }

    /** Called by the melee goal: Steve jumps toward the target so the landing hit is a critical. */
    public boolean canCritLeap() {
        return ready(Ability.CRIT_LEAP) && this.onGround && !isBusy() && !isShielding();
    }

    public void critLeap(EntityLivingBase target) {
        use(Ability.CRIT_LEAP);
        double dx = target.posX - this.posX;
        double dz = target.posZ - this.posZ;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.001D) len = 0.001D;
        this.motionX = dx / len * 0.45D;
        this.motionZ = dz / len * 0.45D;
        this.motionY = 0.52D;
        this.isAirBorne = true;
        sound(SteveSounds.CRIT_LEAP, 0.8F, 1.4F);
    }

    // =====================================================================
    // 7. HELPERS
    // =====================================================================
    public boolean isBusy()     { return slamTicks > 0 || totemTicks > 0; }
    public boolean isShielding(){ return shieldTicks > 0; }
    public int getPhase()       { return this.dataWatcher.getWatchableObjectInt(DW_PHASE); }
    public int getState()       { return this.dataWatcher.getWatchableObjectInt(DW_STATE); }

    private boolean ready(Ability a) { return cooldowns[a.ordinal()] <= 0; }

    private void use(Ability a) {
        float scale = (phase == 3) ? 0.65F : 1.0F; // faster abilities in the enrage phase
        cooldowns[a.ordinal()] = (int) (a.cooldown * scale);
    }

    private void tickCooldowns() {
        for (int i = 0; i < cooldowns.length; i++) {
            if (cooldowns[i] > 0) cooldowns[i]--;
        }
    }

    /** Pushes the current animation state to the DataWatcher so the client model can pose. */
    private void syncState() {
        int s;
        if (totemTicks > 0)      s = STATE_TOTEM;
        else if (slamTicks > 0)  s = STATE_SLAM;
        else if (shieldTicks > 0)s = STATE_SHIELD;
        else if (bowMode)        s = STATE_BOW;
        else                     s = STATE_IDLE;
        if (s != getState()) this.dataWatcher.updateObject(DW_STATE, Integer.valueOf(s));
    }

    /** Damages (optionally) and knocks back every non-creative player within the radius. */
    private void shockwave(double radius, float damage, double power) {
        AxisAlignedBB area = this.boundingBox.expand(radius, 3.0D, radius);
        List players = this.worldObj.getEntitiesWithinAABB(EntityPlayer.class, area);
        for (Object o : players) {
            EntityPlayer p = (EntityPlayer) o;
            if (p.capabilities.disableDamage) continue;
            if (this.getDistanceToEntity(p) > radius) continue;
            if (damage > 0.0F) {
                p.hurtResistantTime = 0;
                p.attackEntityFrom(DamageSource.causeMobDamage(this), damage);
            }
            pushAway(p, power, 0.6D);
        }
    }

    private void pushAway(Entity e, double horizontal, double vertical) {
        double dx = e.posX - this.posX;
        double dz = e.posZ - this.posZ;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.001D) { dx = 1.0D; dz = 0.0D; len = 1.0D; }
        e.addVelocity(dx / len * horizontal, vertical, dz / len * horizontal);
        e.velocityChanged = true; // makes the server send the velocity packet to the player
    }

    /** Server-side particle burst (no custom packets needed - vanilla S2APacketParticles). */
    private void fx(String particle, double x, double y, double z, int count, double spread, double speed) {
        if (this.worldObj instanceof WorldServer) {
            ((WorldServer) this.worldObj).func_147487_a(particle, x, y, z, count, spread, spread, spread, speed);
        }
    }

    private void sound(String name, float volume, float pitch) {
        this.worldObj.playSoundAtEntity(this, name, volume, pitch);
    }

    /** Taunts to every player within 64 blocks. */
    private void say(String msg) {
        for (Object o : this.worldObj.playerEntities) {
            EntityPlayer p = (EntityPlayer) o;
            if (p.getDistanceToEntity(this) < 64.0F) {
                p.addChatMessage(new ChatComponentText("\u00a7e<Steve>\u00a7r " + msg));
            }
        }
    }

    /** CLIENT: aura particles per phase + a counter the model uses for animation timing. */
    private void clientTick() {
        int state = getState();
        if (state != lastClientState) { clientStateTicks = 0; lastClientState = state; }
        else clientStateTicks++;

        int ph = getPhase();
        if (ph >= 2 && this.rand.nextInt(3) == 0) {
            this.worldObj.spawnParticle("smoke", posX + (rand.nextDouble() - 0.5D) * 0.8D, posY + rand.nextDouble() * 2.0D,
                    posZ + (rand.nextDouble() - 0.5D) * 0.8D, 0.0D, 0.02D, 0.0D);
        }
        if (ph >= 3) {
            this.worldObj.spawnParticle("flame", posX + (rand.nextDouble() - 0.5D) * 0.6D, posY + rand.nextDouble() * 2.0D,
                    posZ + (rand.nextDouble() - 0.5D) * 0.6D, 0.0D, 0.03D, 0.0D);
            if (this.rand.nextInt(2) == 0) {
                this.worldObj.spawnParticle("witchMagic", posX + (rand.nextDouble() - 0.5D) * 0.8D, posY + rand.nextDouble() * 2.0D,
                        posZ + (rand.nextDouble() - 0.5D) * 0.8D, 0.0D, 0.0D, 0.0D);
            }
        }
    }

    // ---------------------------------------------------------------------
    // Drops, sounds, persistence
    // ---------------------------------------------------------------------
    @Override
    protected void dropFewItems(boolean recentlyHit, int looting) {
        this.entityDropItem(new ItemStack(Items.diamond, 24 + this.rand.nextInt(16)), 0.5F);
        this.entityDropItem(new ItemStack(Items.golden_apple, 2, 1), 0.5F); // enchanted golden apples
        this.entityDropItem(new ItemStack(Items.nether_star, 1), 0.5F);
    }

    @Override protected String getHurtSound()  { return SteveSounds.HURT; }
    @Override protected String getDeathSound() { return SteveSounds.DEATH; }

    @Override
    public void writeEntityToNBT(NBTTagCompound nbt) {
        super.writeEntityToNBT(nbt);
        nbt.setBoolean("TotemUsed", totemUsed);
        nbt.setInteger("SteveBossPhase", phase);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound nbt) {
        super.readEntityFromNBT(nbt);
        totemUsed = nbt.getBoolean("TotemUsed");
        phase = Math.max(1, nbt.getInteger("SteveBossPhase"));
        this.dataWatcher.updateObject(DW_PHASE, Integer.valueOf(phase));
    }
}
