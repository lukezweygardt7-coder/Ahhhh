package com.steveboss.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.world.World;

/**
 * Primed TNT that hurts players but does NOT destroy blocks (so the boss arena survives).
 * The vanilla client just sees a normal primed TNT (the tracker uses instanceof EntityTNTPrimed).
 */
public class EntitySteveTNT extends EntityTNTPrimed {

    /** Blast strength. Vanilla TNT is 4.0. */
    public static final float BLAST_POWER = 3.0F;

    public EntitySteveTNT(World world) {
        super(world);
    }

    public EntitySteveTNT(World world, double x, double y, double z, EntityLivingBase igniter) {
        super(world, x, y, z, igniter);
    }

    @Override
    public void onUpdate() {
        // Copy of vanilla physics, but with our own explode().
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.motionY -= 0.04D;
        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        this.motionX *= 0.98D;
        this.motionY *= 0.98D;
        this.motionZ *= 0.98D;

        if (this.onGround) {
            this.motionX *= 0.7D;
            this.motionZ *= 0.7D;
            this.motionY *= -0.5D;
        }

        if (this.fuse-- <= 0) {
            this.setDead();
            if (!this.worldObj.isRemote) {
                // last argument = "destroy blocks" -> false
                this.worldObj.createExplosion(this, this.posX, this.posY + (double) (this.height / 16.0F),
                        this.posZ, BLAST_POWER, false);
            }
        } else {
            this.worldObj.spawnParticle("smoke", this.posX, this.posY + 0.5D, this.posZ, 0.0D, 0.0D, 0.0D);
        }
    }
}
