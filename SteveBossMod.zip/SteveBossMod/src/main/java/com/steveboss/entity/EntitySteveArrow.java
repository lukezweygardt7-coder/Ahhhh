package com.steveboss.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.world.World;

/**
 * Steve's "spectral" arrow (1.7.10 has no real spectral arrows).
 * Armour piercing is applied in SteveEvents (LivingAttackEvent), which swaps the
 * damage source for one that bypasses armour.
 */
public class EntitySteveArrow extends EntityArrow {

    private int life = 0;

    public EntitySteveArrow(World world) {
        super(world);
    }

    public EntitySteveArrow(World world, EntityLivingBase shooter, EntityLivingBase target,
                            float velocity, float inaccuracy) {
        super(world, shooter, target, velocity, inaccuracy);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        // Don't litter the arena: remove after 5 seconds no matter what.
        if (!this.worldObj.isRemote && ++this.life > 100) {
            this.setDead();
        }
    }
}
